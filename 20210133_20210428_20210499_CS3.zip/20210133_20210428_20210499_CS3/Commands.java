/// @author1: Rana Essam  20210133
/// @author2 : Nour Mohamed 20210428
/// @author3 : Noor Eyad   20210499
/// Created on: 25/10/2023
/// Last modification: 3/11/2023

//This enum contains all the commands that the user can write on the terminal
public enum Commands {
    echo, //Done // Done
    pwd, // Done // Done
    cd, // Done  // Done
    ls, // && ls -r // Done // Done
    mkdir, // Done // Done
    rmdir, // Done
    history, // Done
    rm, // Done
    cat, // Done
    //" >"  // Done
    wc, // Done
    cp,
    touch //Done

}

